# flappy-bird
A game of Flappy Bird made in pure JavaScript, HTML and CSS

Work In progress
